# TradeLens V4

TradeLens V4 is a static, HTTPS-ready paper-trading analyzer.

## What changed from V3.1
- Designed to be hosted as `index.html` instead of opened from `content://downloads/...`.
- Tests six Binance Spot API base endpoints.
- Uses live candlestick data when reachable.
- Includes EMA20/EMA50, RSI14, MACD, ATR14, basic structure, risk calculations, chart, and paper journal.
- Does not place real orders.

## Recommended hosting: GitHub Pages
1. Create a GitHub account if you do not already have one.
2. Create a new repository, for example `tradelens`.
3. Upload `index.html` from this folder.
4. Open the repository's **Settings → Pages**.
5. Choose the main branch and root folder as the publishing source.
6. Save and open the generated `https://<username>.github.io/tradelens/` address.
7. On the live site, tap **Test API**, then **Load live market**.

GitHub Pages publishes static HTML/CSS/JavaScript and supports HTTPS.

## Important
If the live site still cannot reach Binance, the problem is no longer the local `content://` origin. It may be the network, DNS, VPN, browser restrictions, or Binance availability from the connection being used.
